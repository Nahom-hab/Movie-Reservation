const { sendToTelegram } = require("../config/sendTelegramMessage");
const Ticket = require("../models/Recipt");


const sendMessage = async (req, res) => {
    const { ticket_id, chatId, username, total, totalTicket, imageUrl } = req.body;


    const text = `You have succsusfully purchased ${totalTicket} ticket from Fikat cinema
with total mony of ${total}ETB with username ${username} and dont forget to come to the cinema on sunday
for more information contact telegram: @nahom_hab or with phone number: 0907702898
`
    // Validate input
    if (!chatId || !text) {
        return res.status(400).send('Chat ID and text are required');
    }


    try {
        await sendToTelegram(chatId, text, imageUrl);
        const ticket = await Ticket.findById(ticket_id);
        ticket.ticketStatus = 'Approved'
        ticket.save()
        res.status(200).send('Message sent successfully');

    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Internal Server Error');
    }
}


module.exports = {
    sendMessage
};
