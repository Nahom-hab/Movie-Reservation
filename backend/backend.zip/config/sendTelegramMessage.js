const { Telegraf } = require('telegraf');

// Initialize the bot with your bot token
const bot = new Telegraf('8028749136:AAGqwgStkKI8lHfWET_jQoXVb4w3NdiUCmk');

// Controller function to send the image and text to the Telegram chat
const sendToTelegram = async (chatId, text, imageUrl) => {
    try {
        // Send the image with the text as a caption
        if (imageUrl) {
            await bot.telegram.sendPhoto(chatId, imageUrl, { caption: text });
        } else {
            // If no image, just send the text
            await bot.telegram.sendMessage(chatId, text);
        }
    } catch (error) {
        console.error('Error sending to Telegram:', error);
    }
};

module.exports = { sendToTelegram };
